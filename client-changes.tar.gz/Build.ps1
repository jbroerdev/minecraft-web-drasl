$ErrorActionPreference = 'Stop'
$repoPath = $PSScriptRoot
$toolsPath = Join-Path (Split-Path $repoPath -Parent) 'minecraft-tools'
$jdkPath = Get-ChildItem (Join-Path $toolsPath 'jdk') -Directory | Select-Object -First 1 -ExpandProperty FullName
$ffmpegPath = Get-ChildItem (Join-Path $toolsPath 'ffmpeg') -Recurse -Filter ffmpeg.exe | Select-Object -First 1 -ExpandProperty FullName
$config = @{
 repositoryFolder=$repoPath
 modCoderPack=(Join-Path $toolsPath 'mcp918.zip')
 minecraftJar=(Join-Path $toolsPath '1.8.8.jar')
 assetsIndex=(Join-Path $toolsPath '1.8.json')
 outputDirectory=(Join-Path $repoPath 'web-dist')
 temporaryDirectory=(Join-Path $repoPath '.build/client')
 ffmpeg=$ffmpegPath
 mavenURL='https://repo.maven.apache.org/maven2/'
 mavenLocal=(Join-Path $toolsPath 'maven')
 productionIndex=(Join-Path $repoPath 'buildtools/production-index.html')
 productionFavicon=(Join-Path $repoPath 'buildtools/production-favicon.png')
 generateOfflineDownload=$false
 keepTemporaryFiles=$true
 minifying=$true
}
$configPath=Join-Path $repoPath 'build-config.json'
$config | ConvertTo-Json | Set-Content -Encoding utf8 $configPath
& (Join-Path $jdkPath 'bin/java.exe') -Xmx2G -cp (Join-Path $repoPath 'buildtools/BuildTools.jar') net.lax1dude.eaglercraft.v1_8.buildtools.gui.headless.CompileLatestClientHeadless -y $configPath
if($LASTEXITCODE -ne 0){throw 'Client build failed'}
$pluginPath=Join-Path $repoPath 'gateway/DraslLogin'
New-Item -ItemType Directory -Force (Join-Path $pluginPath 'build/classes') | Out-Null
& (Join-Path $jdkPath 'bin/javac.exe') -encoding UTF-8 -source 8 -target 8 -cp "$(Join-Path $toolsPath 'BungeeCord.jar');$(Join-Path $repoPath 'gateway/EaglercraftXBungee/EaglerXBungee-Latest.jar')" -d (Join-Path $pluginPath 'build/classes') (Join-Path $pluginPath 'src/main/java/app/xserverx/drasl/DraslLogin.java')
if($LASTEXITCODE -ne 0){throw 'Gateway plugin build failed'}
Copy-Item (Join-Path $pluginPath 'src/main/resources/*') (Join-Path $pluginPath 'build/classes/')
& (Join-Path $jdkPath 'bin/jar.exe') cf (Join-Path $pluginPath 'DraslLogin.jar') -C (Join-Path $pluginPath 'build/classes') .

Copy-Item (Join-Path $repoPath 'buildtools/input-focus.js') (Join-Path $repoPath 'web-dist/input-focus.js') -Force

Copy-Item (Join-Path $repoPath 'buildtools/performance.js') (Join-Path $repoPath 'web-dist/performance.js') -Force
