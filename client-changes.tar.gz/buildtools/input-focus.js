/* Keep keyboard input in the game document, including Firefox and nested frames. */
(() => {
  const focusGame = canvas => {
    canvas = canvas || document.querySelector('canvas');
    if (!canvas) return;
    if (canvas.tabIndex < 0) canvas.tabIndex = 0;
    canvas.setAttribute('aria-label', 'Minecraft Spielfläche');
    try { window.focus(); canvas.focus({ preventScroll: true }); }
    catch { canvas.focus(); }
  };
  const prepare = () => {
    for (const canvas of document.querySelectorAll('canvas')) {
      if (canvas.dataset.minecraftFocusReady) continue;
      canvas.dataset.minecraftFocusReady = 'true';
      canvas.tabIndex = 0;
      canvas.style.outline = 'none';
      canvas.addEventListener('pointerdown', () => focusGame(canvas), true);
      canvas.addEventListener('mousedown', () => focusGame(canvas), true);
    }
  };
  addEventListener('message', event => {
    if (event.source === parent && event.origin === new URL(document.baseURI).origin && event.data?.type === 'minecraft-focus') focusGame();
  });
  document.addEventListener('pointerlockchange', () => { if (document.pointerLockElement) focusGame(document.pointerLockElement); });
  new MutationObserver(prepare).observe(document.documentElement, { childList: true, subtree: true });
  prepare();
})();
