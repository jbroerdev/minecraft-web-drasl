(() => {
  const valid = value => value === 0 || value === 1 || value === 2 || value === 3;
  let stored = 2;
  try { const raw=localStorage.getItem('minecraft.performance'); if(raw!==null&&valid(Number(raw)))stored=Number(raw); } catch {}
  window.minecraftPerformanceMode = stored;
  addEventListener('message', event => {
    if (event.source !== parent || event.origin !== new URL(document.baseURI).origin || event.data?.type !== 'minecraft-performance') return;
    const value=event.data.mode;
    if(!valid(value))return;
    window.minecraftPerformanceMode=value;
    try {localStorage.setItem('minecraft.performance',String(value));} catch {}
  });
})();
