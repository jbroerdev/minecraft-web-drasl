package net.lax1dude.eaglercraft.v1_8.internal;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;

/** Runtime presets. The player's saved graphics options are not overwritten. */
final class PerformanceTuning {
    private static int applied = -1;
    private static GameSettings original;
    private static int distance, clouds, ao, particles, fxaa;
    private static boolean fancy, dynamicLights;

    static void update() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc == null || mc.gameSettings == null) return;
        GameSettings settings = mc.gameSettings;
        int mode = PlatformInput.getPerformanceMode();
        if (original != settings) {
            original = settings;
            distance = settings.renderDistanceChunks; clouds = settings.clouds;
            ao = settings.ambientOcclusion; particles = settings.particleSetting;
            fxaa = settings.fxaa; fancy = settings.fancyGraphics;
            dynamicLights = settings.enableDynamicLights;
            applied = -1;
        }
        if (mode == applied) return;
        int oldDistance = settings.renderDistanceChunks;
        if (mode == 0) {
            settings.renderDistanceChunks = distance; settings.clouds = clouds;
            settings.ambientOcclusion = ao; settings.particleSetting = particles;
            settings.fxaa = fxaa; settings.fancyGraphics = fancy;
            settings.enableDynamicLights = dynamicLights;
        } else {
            settings.renderDistanceChunks = mode == 3 ? 2 : mode == 2 ? 3 : 4;
            settings.clouds = 0; settings.fancyGraphics = false;
            settings.ambientOcclusion = 0;
            settings.particleSetting = mode >= 2 ? 2 : 1;
            settings.fxaa = 2; settings.enableDynamicLights = false;
        }
        applied = mode;
        if (oldDistance != settings.renderDistanceChunks && mc.theWorld != null && mc.renderGlobal != null) mc.renderGlobal.loadRenderers();
    }
}
