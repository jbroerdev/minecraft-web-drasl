package net.lax1dude.eaglercraft.v1_8.internal;

import org.teavm.jso.JSBody;

/** Runtime-only identity supplied by the authenticated launcher. Never persisted. */
public final class DraslSession {
    @JSBody(script = "return window.draslSession ? window.draslSession.name : null;")
    public static native String getName();

    @JSBody(script = "return window.draslSession ? window.draslSession.uuid : null;")
    public static native String getUUID();

    @JSBody(params = {"uri"}, script = "var s=window.draslSession; if(!s || !s.gateway || !s.ticket) return null; try { var a=new URL(uri), b=new URL(s.gateway); if(a.href!==b.href) return null; if(a.protocol!=='wss:' && !(a.protocol==='ws:' && (a.hostname==='127.0.0.1'||a.hostname==='localhost'))) return null; return s.ticket; } catch(e) { return null; }")
    public static native String getTicket(String uri);
}
