package net.lax1dude.eaglercraft.v1_8.internal;

/** The desktop development harness has no browser login session. */
public final class DraslSession {
    public static String getName() { return null; }
    public static String getUUID() { return null; }
    public static String getTicket(String uri) { return null; }
}
