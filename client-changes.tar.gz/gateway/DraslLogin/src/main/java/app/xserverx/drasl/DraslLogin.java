package app.xserverx.drasl;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.Arrays;
import java.util.concurrent.*;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.ConfigurationProvider;
import net.md_5.bungee.config.YamlConfiguration;
import net.lax1dude.eaglercraft.v1_8.plugin.gateway_bungeecord.api.event.EaglercraftIsAuthRequiredEvent;
import net.lax1dude.eaglercraft.v1_8.plugin.gateway_bungeecord.api.event.EaglercraftHandleAuthPasswordEvent;

/** Server-side Drasl identity verification for the repository's gateway API. */
public final class DraslLogin extends Plugin implements Listener {
    private URI verifier;
    private String secret;
    private ExecutorService workers;
    private boolean ready;

    @Override public void onEnable() {
        // Register even on configuration failure: every browser login must fail closed.
        getProxy().getPluginManager().registerListener(this, this);
        try {
            getDataFolder().mkdirs();
            File file = new File(getDataFolder(), "config.yml");
            if (!file.exists()) try (InputStream in=getResourceAsStream("config.yml");OutputStream out=new FileOutputStream(file)) {
                byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
            }
            Configuration config=ConfigurationProvider.getProvider(YamlConfiguration.class).load(file);
            verifier=URI.create(config.getString("verify_url"));secret=config.getString("gateway_secret");
            if (secret == null || secret.length()<32 || secret.startsWith("REPLACE"))throw new IllegalArgumentException("Set gateway_secret in config.yml");
            if (!"https".equals(verifier.getScheme()) && !("http".equals(verifier.getScheme()) && "127.0.0.1".equals(verifier.getHost())))throw new IllegalArgumentException("Verifier requires HTTPS or loopback HTTP");
            workers=new ThreadPoolExecutor(2,4,30,TimeUnit.SECONDS,new ArrayBlockingQueue<Runnable>(64));
            ready=true;
            getLogger().info("Drasl gateway authentication enabled");
        } catch(Exception ex) { getLogger().severe("Drasl configuration invalid; browser logins are denied: "+ex.getMessage()); }
    }
    @Override public void onDisable() { ready=false;if(workers!=null)workers.shutdownNow(); }

    @EventHandler public void require(EaglercraftIsAuthRequiredEvent event) {
        getLogger().info("Drasl authentication requested");
        if (!ready) {event.kickUser("Drasl-Anmeldung ist nicht verfügbar.");return;}
        event.setAuthRequired(EaglercraftIsAuthRequiredEvent.AuthResponse.REQUIRE);
        event.setUseAuthMethod(EaglercraftIsAuthRequiredEvent.AuthMethod.PLAINTEXT);
        event.setAuthMessage("Bitte über den Minecraft-Login bei Drasl anmelden.");
    }
    @EventHandler public void authenticate(final EaglercraftHandleAuthPasswordEvent event) {
        getLogger().info("Drasl ticket verification requested");
        event.setLoginDenied("Drasl-Sitzung ungültig. Bitte erneut anmelden.");
        if (!ready || event.getAuthType()!=EaglercraftIsAuthRequiredEvent.AuthMethod.PLAINTEXT)return;
        final byte[] bytes=event.getAuthPasswordDataResponse();
        if (bytes.length!=128)return; // 64 hex characters encoded as Java UTF-16BE by this client
        final String ticket=new String(bytes,StandardCharsets.UTF_16BE);
        Arrays.fill(bytes,(byte)0);
        if(!ticket.matches("[a-f0-9]{64}"))return;
        final Runnable resume=event.makeAsyncContinue();
        try {workers.execute(()->{
            try {
                JsonObject profile=verify(verifier,secret,ticket);
                String name=profile.get("name").getAsString();
                if(!name.matches("[A-Za-z0-9_]{1,16}"))throw new IOException("Invalid profile");
                UUID id=UUID.fromString(profile.get("uuid").getAsString());
                // The claimed client username and UUID never establish identity.
                event.setProfileUsername(name);event.setProfileUUID(id);event.setLoginAllowed();
            } catch(Exception ex) { getLogger().warning("Drasl verification failed: "+ex.getClass().getSimpleName()+": "+ex.getMessage()); event.setLoginDenied("Drasl-Sitzung abgelaufen oder Login-Dienst nicht erreichbar."); }
            finally {resume.run();}
        });} catch(RejectedExecutionException ex) {event.setLoginDenied("Anmeldung ausgelastet. Bitte erneut versuchen.");resume.run();}
    }
    public static JsonObject verify(URI endpoint,String secret,String ticket) throws IOException {
        HttpURLConnection connection=(HttpURLConnection)endpoint.toURL().openConnection();
        connection.setConnectTimeout(5000);connection.setReadTimeout(20000);connection.setInstanceFollowRedirects(false);
        connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");connection.setRequestProperty("X-Drasl-Gateway-Secret",secret);
        try {
            byte[] payload=("{\"ticket\":\""+ticket+"\"}").getBytes(StandardCharsets.UTF_8);
            try(OutputStream out=connection.getOutputStream()){out.write(payload);}
            if(connection.getResponseCode()!=200)throw new IOException("Session rejected");
            try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                byte[] buffer=new byte[1024];int n;while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>8192)throw new IOException("Response too large");}
                return new JsonParser().parse(new String(out.toByteArray(),StandardCharsets.UTF_8)).getAsJsonObject();
            }
        }finally{connection.disconnect();}
    }
}
