# Minecraft 1.8.8 mit Drasl

Basis: https://github.com/3kh0/eaglercraft-1.8, Stand u35, Commit `4cb71c5033b9e42245963464976aaa9a799703b4`. Die JavaScript-Ausgabe wird aus den angepassten Quellen gebaut. Die alte ZIP wird nicht mehr als Spielclient verwendet.

## Lokal starten

1. `./Start-Launcher.ps1` starten und http://127.0.0.1:8790 öffnen.
2. In einem weiteren Terminal `./Start-Gateway.ps1` starten.
3. Mit dem Drasl-Spielernamen und Passwort oder Minecraft-Token anmelden. Im Mehrspielermenü ist der lokale Gateway als „Minecraft“ eingetragen.

Zielserver: **193.181.217.200:25565**, Minecraft 1.8.9. Der Gateway leitet intern auf die ausschließlich lokal gebundene Online-Bridge `127.0.0.1:25579` weiter. Diese meldet die bestätigte Drasl-Sitzung verschlüsselt beim Zielserver an. Dessen Online-Modus bleibt aktiviert.

## Anmeldeweg

- Der Launcher authentifiziert bei https://drasl.xserverx.app/auth/authenticate.
- Nur der bestätigte Drasl-Spielername und die UUID werden im Spielprofil verwendet; der Name lässt sich im Profilmenü nicht überschreiben.
- Der Client bekommt ein separates, zufälliges Gateway-Ticket. Das Drasl-Zugriffstoken bleibt im Arbeitsspeicher des Launchers. Passwörter werden nicht gespeichert.
- Das Ticket wird nur an den exakt eingestellten Gateway gesendet. Entfernte Gateways benötigen `wss://`; lokales `ws://` ist auf localhost/127.0.0.1 beschränkt.
- DraslLogin.jar prüft Tickets über den Launcher und dieser prüft bei jedem Beitritt die Drasl-Sitzung über `/auth/validate`. Das Gateway übernimmt den bestätigten Namen und die UUID statt der vom Client behaupteten Identität.
- Abmeldung, Sitzungsablauf (eine Stunde), Drasl-Widerruf und Launcher-Neustart machen Tickets ungültig. Abmeldung schließt den eingebetteten Spielclient.
- Der gemeinsame Gateway-Schlüssel liegt unter `launcher/.runtime/gateway-secret` und darf nicht ins Web oder Git gelangen. Laufzeitdateien sind ignoriert.

## Oberfläche

Minecraft-Titel und Original-Menülogo, Mojang-Ladebildschirm, Minecraft-Favicon und angepasste sichtbare Texte. Eingebaute Skin-Auswahl auf Steve/Alex beschränkt. Zusätzliche FNAW-Skins, Sprachchat und Client-Updates sind deaktiviert. Der alte Gateway-Plugin-Download-Link im Mehrspielermenü ist entfernt. Vorhandene technische Paketnamen, WebSocket-Protokolle und Herkunfts-/Lizenzhinweise bleiben erhalten. Drasl-Skins/Capes werden noch nicht automatisch aus dem Konto geladen. Browserspezifische Funktionen wie Welt-Import/-Export bleiben vorhanden.

## Build und Tests

`./Build.ps1` erstellt `web-dist/` und `gateway/DraslLogin/DraslLogin.jar`. Die lokal beschafften Werkzeuge und Eingaben liegen im benachbarten Verzeichnis `../minecraft-tools/`: Temurin Java 17, MCP 9.18, offizieller Minecraft-1.8.8-Client samt Asset-Index, FFmpeg, TeaVM/Maven-Abhängigkeiten, BungeeCord Build 1849 (der vom Gateway genannte kompatible Stand), trove4j und ws 8.22.0 für den WebSocket-Test. Der Build schreibt ausschließlich `web-dist/` und `.build/` neu.

`node --test launcher/server.test.mjs` prüft den Anmeldeweg mit simuliertem Drasl, falschen Tickets, fremdem Origin, Widerruf und Abmeldung gegen den gebauten Client.

`node launcher/gateway-smoke.mjs` prüft den echten Gateway-Handschlag mit `DRASL_TEST_USERNAME` und `DRASL_TEST_PASSWORD` aus der Umgebung. Zugangsdaten sind nicht im Test gespeichert. Der Test versucht absichtlich eine fremde Client-Identität; nur das Drasl-Profil darf übernommen werden.

Für einen entfernten Server `DRASL_GATEWAY_URL=wss://.../` beim Launcher setzen. Gateway und Launcher müssen den gemeinsamen Schlüssel verwenden; die Verify-URL im Gateway muss den Launcher sicher erreichen. Die mitgelieferte Konfiguration ist ausschließlich lokal gebunden. Ein öffentliches Hosting muss separat eingerichtet werden.

## Verifizierter Stand

Client-Build erfolgreich; Login und Minecraft-Hauptmenü im Browser geprüft. Automatischer Launcher-Test bestanden. Echter Gateway-Handschlag mit Drasl-Testkonto bestanden: gefälschte Tickets abgewiesen, absichtlich falscher Client-Name durch bestätigten Drasl-Namen/UUID ersetzt, Ticket nach Abmeldung abgewiesen. Der vollständige Weltbeitritt zu 193.181.217.200:25565 wurde mit dem Testkonto über Gateway und Online-Bridge nachgewiesen.

## Online-Bridge

`Start-Launcher.ps1` startet automatisch auch die Online-Bridge. Sie verwendet minecraft-protocol 1.68.0 (Abhängigkeiten mit `pnpm --dir launcher install --frozen-lockfile` installieren). Pro Gateway-Prüfung wird intern eine nur 20 Sekunden gültige, einmalig verwendbare Freigabe für genau Spielername und weitergeleitete UUID erzeugt. Ohne diese Freigabe wird keine Verbindung zum Zielserver aufgebaut. Drasl-Zugriffstokens bleiben im Launcher-Prozess und werden nur an Drasl gesendet.

Der Zielserver kann über `MINECRAFT_HOST` und `MINECRAFT_PORT` eingestellt werden. Die Bridge ist für Minecraft-Protokoll 47 (1.8.8/1.8.9) eingerichtet. `node launcher/upstream-smoke.mjs` mit den beiden Testkonto-Umgebungsvariablen prüft den tatsächlichen Weltbeitritt und beendet die Testsitzung anschließend.
